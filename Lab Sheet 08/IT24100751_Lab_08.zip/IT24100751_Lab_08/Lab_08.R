setwd("C:\\Users\\it24100751\\Desktop\\IT24100751")
data <- read.table("Exercise - LaptopsWeights.txt",header=TRUE)
fix(data)
attach(data)


pop_mean_laptop <-mean(Weight.kg.)
pop_sd_laptop <-sd(Weight.kg.)


samples_laptop <- c()
n_laptop <- c()

for (i in 1:25){
  s_laptop <- sample(Weight.kg.,6,replace = TRUE)
  samples_laptop <-cbind(samples_laptop,s_laptop)
  n_laptop <-c(n_laptop,paste('S',i))
}

colnames(samples_laptop) =n_laptop

s.mean_laptop <- apply(samples_laptop,2,mean)
s.sd_laptop <- apply(samples_laptop,2,sd)

mean_of_s_means <- mean(s.mean_laptop)
sd_of_s_means <- sd(s.mean_laptop)

pop_mean_laptop
mean_of_s_means

pop_sd_laptop
sd_of_s_means
