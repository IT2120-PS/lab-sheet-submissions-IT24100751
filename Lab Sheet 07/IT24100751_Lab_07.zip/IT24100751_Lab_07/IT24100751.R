{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 R version 4.5.1 (2025-06-13) -- "Great Square Root"\
Copyright (C) 2025 The R Foundation for Statistical Computing\
Platform: x86_64-apple-darwin20\
\
R is free software and comes with ABSOLUTELY NO WARRANTY.\
You are welcome to redistribute it under certain conditions.\
Type 'license()' or 'licence()' for distribution details.\
\
  Natural language support but running in an English locale\
\
R is a collaborative project with many contributors.\
Type 'contributors()' for more information and\
'citation()' on how to cite R or R packages in publications.\
\
Type 'demo()' for some demos, 'help()' for on-line help, or\
'help.start()' for an HTML browser interface to help.\
Type 'q()' to quit R.\
\
[R.app GUI 1.82 (8536) x86_64-apple-darwin20]\
\
[Workspace restored from /Users/thilomithpeiris/.RData]\
[History restored from /Users/thilomithpeiris/.Rapp.history]\
\
> setwd("/Users/thilomithpeiris/Desktop")\
> prob_ex1 <- punif(25, min = 0, max = 40, lower.tail = TRUE) - \
+             punif(10, min = 0, max = 40, lower.tail = TRUE)\
> cat("Exercise 1: Probability train arrives between 8:10-8:25:", prob_ex1, "\\n\\n")\
Exercise 1: Probability train arrives between 8:10-8:25: 0.375 \
\
> prob_ex2 <- pexp(2, rate = 1/3, lower.tail = TRUE)\
> cat("Exercise 2: Probability update takes at most 2 hours:", prob_ex2, "\\n\\n")\
Exercise 2: Probability update takes at most 2 hours: 0.4865829 \
\
> \
> prob_ex3i <- pnorm(130, mean = 100, sd = 15, lower.tail = FALSE)\
> cat("Exercise 3(i): Probability IQ above 130:", prob_ex3i, "\\n")\
Exercise 3(i): Probability IQ above 130: 0.02275013 \
> \
> iq_ex3ii <- qnorm(0.95, mean = 100, sd = 15, lower.tail = TRUE)\
> cat("Exercise 3(ii): IQ score at 95th percentile:", iq_ex3ii, "\\n")\
Exercise 3(ii): IQ score at 95th percentile: 124.6728 \
> \
> }